﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HuffmanKod
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int liczba;

        private void button1_Click(object sender, EventArgs e)
        {
            string tekst = textBox1.Text;
            if (string.IsNullOrEmpty(tekst))
            {
                MessageBox.Show("Wprowadź tekst do zakodowania!");
                return;
            }

            var slownikCzestosci = czestosc(tekst);
            var root = StworzDrzewoHuffmana(slownikCzestosci);
            var kody = new Dictionary<char, string>();
            GenerujKody(root, "", kody);

            StringBuilder zakodowanyTekst = new StringBuilder();
            foreach (char c in tekst)
            {
                zakodowanyTekst.Append(kody[c]);
            }

            MessageBox.Show("Zakodowany tekst: " + zakodowanyTekst.ToString());
        }
        public Dictionary<char, int> czestosc(string tekst)
        {
            var slownikCzestosci = new Dictionary<char, int>();

            foreach (var litera in tekst)
            {
                if (slownikCzestosci.ContainsKey(litera))
                {
                    slownikCzestosci[litera]++;
                }
                else
                {
                    slownikCzestosci[litera] = 1;
                }
            }

            return slownikCzestosci;
        }

        public NodeG StworzDrzewoHuffmana(Dictionary<char, int> czestosc)
        {
            var wezelLista = new List<NodeG>();

            foreach (var symbol in czestosc)
            {
                wezelLista.Add(new NodeG(symbol.Value, symbol.Key));
            }

            while (wezelLista.Count > 1)
            {
                // Znajdź dwa węzły o najmniejszej częstotliwości
                wezelLista = wezelLista.OrderBy(w => w.czestotliwosc).ToList();
                var lewe = wezelLista[0];
                var prawe = wezelLista[1];

                // Stwórz nowy węzeł, który łączy dwa poprzednie
                var nowyWezel = new NodeG(lewe.czestotliwosc + prawe.czestotliwosc, null)
                {
                    lewe = lewe,
                    prawe = prawe
                };

                // Usuń dwa najmniejsze węzły i dodaj nowy węzeł do listy
                wezelLista.Remove(lewe);
                wezelLista.Remove(prawe);
                wezelLista.Add(nowyWezel);
            }

            // Zwróć korzeń drzewa (ostatni element na liście)
            return wezelLista.First();
        }
        public void GenerujKody(NodeG node, string kod, Dictionary<char, string> kody)
        {
            if (node == null)
                return;

            if (node.symbol != null)
            {
                kody[node.symbol.Value] = kod;
            }

            GenerujKody(node.lewe, kod + "0", kody);
            GenerujKody(node.prawe, kod + "1", kody);
        }
    }
}
