﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HuffmanKod
{
    public class NodeG
    {
        public char? symbol;
        public NodeG lewe;
        public NodeG prawe;
        public int czestotliwosc;

        public NodeG(int czestotliwosc, char? symbol)
        {
            this.symbol = symbol;
            this.czestotliwosc = czestotliwosc;
            lewe = null;
            prawe = null;
        }
    }
}
