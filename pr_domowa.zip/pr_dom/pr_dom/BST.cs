﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_dom
{
    internal class BST
    {
        public Node root;
        public BST()
        {
            this.root = null;
        }

        public void Add(int liczba)
        {
            Node newNode = new Node(liczba);
            if (root == null)
            {
                root = newNode;
            }
            else
            {
                AddRecursive(root, newNode);
            }
        }

        public void AddRecursive(Node current, Node newNode)
        {
            if (newNode.data < current.data)
            {
                if (current.left == null)
                {
                    current.left = newNode;
                    newNode.parent = current;
                }
                else
                {
                    AddRecursive(current.left, newNode);
                }
            }
            else if (newNode.data > current.data)
            {
                if (current.right == null)
                {
                    current.right = newNode;
                    newNode.parent = current;
                }
                else
                {
                    AddRecursive(current.right, newNode);
                }
            }
        }
        public List<int> DisplayTree()
        { 
            List<int> result = new List<int>();
            InOrderTraversal(root,result);
            return result;
        }
        public void InOrderTraversal(Node node, List<int> result)
        {
            if(node != null)
            {
                InOrderTraversal(node.left,result);
                result.Add(node.data);
                InOrderTraversal(node.right,result);
            }
        }
        public List<int> PreOrderTraversal()
        {
            List<int> result = new List<int> ();
            PreOrderTraversalHelper(root, result);
            return result;
        }
        public void PreOrderTraversalHelper(Node node, List<int> result)
        {
            if(node != null)
            {
                result.Add(node.data);
                PreOrderTraversalHelper(node.left,result);
                PreOrderTraversalHelper(node.right,result);
            }
        }
        public List<int> PostOrderTraversal()
        {
            List<int> result = new List<int>();
            PostOrderTraversalHelper(root, result);
            return result;
        }
        public void PostOrderTraversalHelper(Node node, List<int> result)
        {
            if (node != null)
            {
                PostOrderTraversalHelper(node.left,result);
                PostOrderTraversalHelper(node.right,result);
                result.Add (node.data);
            }
        }
    }
}
