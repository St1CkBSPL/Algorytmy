﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_dom
{
    internal class Edges
    {
        public Node start;
        public Node end;
        public int weight;

        public Edges(Node start, Node end, int weight)
        {
            this.start = start;
            this.end = end;
            this.weight = weight;
        }

        public int CompareTo(Edges other)
        {
            return this.weight.CompareTo(other.weight);
        }
        public override string ToString()
        {
            return $"{start.data} -- ({weight}) --> {end.data}";
        }
    }
}
