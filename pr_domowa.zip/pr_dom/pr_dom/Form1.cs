﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr_dom
{
    public partial class Form1 : Form
    {
        List Lista = new List();
        BST myTree = new BST();
        Graf graf = new Graf();
        public Form1()
        {
            InitializeComponent();
        }

        private void AddFirst_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtInput.Text, out int liczba))
            {
                Lista.AddFirst(liczba);
                MessageBox.Show($"Dodano {liczba} na początek listy");
            }
            else
            {
                MessageBox.Show("Wprowadź poprawną liczbe");
            }
        }

        private void AddLast_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtInput.Text, out int liczba))
            {
                Lista.AddLast(liczba);
                MessageBox.Show($"Dodano {liczba} na koniec listy");
            }
            else
            {
                MessageBox.Show("Wprowadz poprawną liczbe");
            }
        }

        private void WyswietlListe_Click(object sender, EventArgs e)
        {
            Liczby.Items.Clear();
            Node current = Lista.head;
            if (current == null)
            {
                MessageBox.Show("Lista jest pusta");
                return;
            }
            while (current != null)
            {
                Liczby.Items.Add(current.data);
                current = current.next;
            }
        }

        private void RemoveLast_Click(object sender, EventArgs e)
        {
            if(Lista.count == 0)
            {
                MessageBox.Show("Lista jest pusta");
            }
            else
            {
                Lista.RemoveLast();
                MessageBox.Show("Usunieto ostatni element z listy");
                WyswietlListe_Click(sender, e);
            }
        }

        private void RemoveFirst_Click(object sender, EventArgs e)
        {
            if (Lista.count == 0)
            {
                MessageBox.Show("Lista jest pusta");
            }
            else
            {
                Lista.RemoveFirst();
                MessageBox.Show("Usunieto pierwszy element z listy");
                WyswietlListe_Click(sender, e);
            }
        }

        private void AddToTree_Click(object sender, EventArgs e)
        {
            if(int.TryParse(InputTree.Text, out int liczba))
            {
                myTree.Add(liczba);
                MessageBox.Show($"Dodano {liczba} do drzewa");
                InputTree.Clear();
            }
            else
            {
                MessageBox.Show("Wprowadź poprawną liczbe");
            }
        }

        private void WyswietlDrzewo_Click(object sender, EventArgs e)
        {
            TreeItems.Items.Clear();
            List<int> treeValues = myTree.DisplayTree();
            if (treeValues.Count == 0)
            {
                MessageBox.Show("Drzewo jest puste");
            }
            else
            {
                foreach (int value in treeValues)
                {
                    TreeItems.Items.Add(value);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TreeItems.Items.Clear();
            List<int> treeValues = myTree.PreOrderTraversal();
            if(treeValues.Count == 0)
            {
                MessageBox.Show("Drzewo jest puste");
            }
            else
            {
                foreach(int value in treeValues)
                {
                    TreeItems.Items.Add(value);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TreeItems.Items.Clear();
            List<int> treeValues = myTree.PostOrderTraversal();
            if (treeValues.Count == 0)
            {
                MessageBox.Show("Drzewo jest puste");
            }
            else
            {
                foreach (int value in treeValues)
                {
                    TreeItems.Items.Add(value);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Node A = new Node(1);
            Node B = new Node(2);
            Node C = new Node(3);
            Node D = new Node(4);
            Node E = new Node(5);
            Node F = new Node(6);
            Node G = new Node(7);

            graf.DodajWierzcholek(A);
            graf.DodajWierzcholek(B);
            graf.DodajWierzcholek(C);
            graf.DodajWierzcholek(D);
            graf.DodajWierzcholek(E);
            graf.DodajWierzcholek(F);
            graf.DodajWierzcholek(G);

            graf.Polacz(A, B);
            graf.Polacz(A, C);
            graf.Polacz(B, A);
            graf.Polacz(B, D);
            graf.Polacz(B, E);
            graf.Polacz(C, A);
            graf.Polacz(C, D);
            graf.Polacz(C, F);
            graf.Polacz(D, B);
            graf.Polacz(D, C);
            graf.Polacz(E, B);
            graf.Polacz(E, F);
            graf.Polacz(F, C);
            graf.Polacz(F, D);
            graf.Polacz(F, E);
            graf.Polacz(F, G);
            graf.Polacz(G, F);

            MessageBox.Show("Graf został stworzony!");

        }

        private void PrzejdzWszerz_Click(object sender, EventArgs e)
        {
            if (graf.nodes.Count > 0)
            {
                Node start = graf.nodes[0];
                List<Node> wynik = graf.Wszerz(start);
                grafWynik.Items.Clear();
                foreach (var w in wynik)
                {
                    grafWynik.Items.Add(w);
                }
            }
            else
            {
                MessageBox.Show("Graf nie został jeszcze stworzony");
            }

        }
    }
}
