﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_dom
{
    internal class Graf
    {
        public List<Node> nodes = new List<Node>();
        public List<Edges> edges = new List<Edges>();

        public void DodajWierzcholek(Node node)
        {
            nodes.Add(node);
        }
        public void Polacz(Node node1, Node node2)
        {
            node1.sasiedzi.Add(node2);
            node2.sasiedzi.Add(node1);
        }
        public List<Node> Wszerz(Node start)
        {
            List<Node> odwiedzone = new List<Node>() { start };
            for (int i = 0; i < odwiedzone.Count; i++)
            {
                var tmp = odwiedzone[i];
                for (int j = 0; j < tmp.sasiedzi.Count; j++)
                {
                    if (!odwiedzone.Contains(tmp.sasiedzi[j]))
                    {
                        odwiedzone.Add(tmp.sasiedzi[j]);
                    }
                }
            }
            return odwiedzone;
        }
        public void DodajKrawedz(Node start, Node end, int weight)
        {
            Edges edge = new Edges(start, end, weight);
            edges.Add(edge);
            start.edges.Add(edge);
            end.edges.Add(edge);
        }

        public List<Edges> MinimalneDrzewoRozpinające()
        {
            List<Edges> mst = new List<Edges>();
            edges.Sort();
            var parent = new Dictionary<Node, Node>();
            var rank = new Dictionary<Node, int>();
            foreach(var node in nodes)
            {
                parent[node] = node;
                rank[node] = 0;
            }
            Node Find(Node node)
            {
                if (parent[node] != node)
                {
                    parent[node] = Find(parent[node]);
                }
                return parent[node];
            }
            void Union(Node node1, Node node2)
            {
                Node root1 = Find(node1);
                Node root2 = Find(node2);
                if (root1 != root2)
                {
                    if (rank[root1] > rank[root2])
                    {
                        parent[root2] = root1;
                    }
                    else if (rank[root1] < rank[root2])
                    {
                        parent[root1] = root2;
                    }
                    else
                    {
                        parent[root2] = root1;
                        rank[root1]++;
                    }
                }
            }
            foreach(var edge in edges)
            {
                if(Find(edge.start) != Find(edge.end))
                {
                    mst.Add(edge);
                    Union(edge.start, edge.end);
                }
            }
            return mst;
        }
        public Dictionary<Node, Node> Dijsktry(Node start)
        {
            var zbiorS = new List <Node>();
            var tabelka = new List<Node>;
            while (true) {
                tabelka
            }
        }
    }
}

