﻿using System;
using System.Collections.Generic;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_dom
{
    internal class Node
    {
        public Node parent;
        public Node start;
        public Node left;
        public Node right;
        public Node next;
        public Node prev;
        public int data;
        private object root;
        public List<Node> sasiedzi = new List<Node>();
        public List<Edges> edges = new List<Edges>();


        public Node(int liczba)
        {
            this.data = liczba;
        }

        public override string ToString()
        {
            return this.data.ToString();
        }
        public int liczbaDzieci()
        {
            int wynik = 0;
            if (this.left != null)
            {
                wynik++;
            }
            if (this.right != null)
            {
                wynik++;
            }
            return wynik;
        }
        public void removeZero(BST root)
        {
            if (this.root == null)
            {
                this.root = parent;
            }
            else
            {
                if (parent.left == null)
                {
                    parent.left = null;
                }
                else if (parent.right == null)
                {
                    parent.right = null;
                }
                parent = null;
            }
        }
        /*
        public Node removeElement1(BST root)
        {
            Node dziecko = null;
            if (this.left != null)
            {
                dziecko = this.left;
            }
            else if (this.right != null)
            {
                dziecko = this.right;
            }
            else
            {
                this.removeZero(dziecko);
                return dziecko;
            }
        }
        */
    }
}
