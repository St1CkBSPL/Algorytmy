﻿namespace pr_dom
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddFirst = new System.Windows.Forms.Button();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.AddLast = new System.Windows.Forms.Button();
            this.Liczby = new System.Windows.Forms.ListBox();
            this.WyswietlListe = new System.Windows.Forms.Button();
            this.RemoveLast = new System.Windows.Forms.Button();
            this.RemoveFirst = new System.Windows.Forms.Button();
            this.InputTree = new System.Windows.Forms.TextBox();
            this.TreeItems = new System.Windows.Forms.ListBox();
            this.AddToTree = new System.Windows.Forms.Button();
            this.WyswietlDrzewo = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.PrzejdzWszerz = new System.Windows.Forms.Button();
            this.grafWynik = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // AddFirst
            // 
            this.AddFirst.Location = new System.Drawing.Point(454, 172);
            this.AddFirst.Name = "AddFirst";
            this.AddFirst.Size = new System.Drawing.Size(75, 23);
            this.AddFirst.TabIndex = 0;
            this.AddFirst.Text = "AddFirst";
            this.AddFirst.UseVisualStyleBackColor = true;
            this.AddFirst.Click += new System.EventHandler(this.AddFirst_Click);
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(454, 55);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(100, 22);
            this.txtInput.TabIndex = 1;
            // 
            // AddLast
            // 
            this.AddLast.Location = new System.Drawing.Point(644, 172);
            this.AddLast.Name = "AddLast";
            this.AddLast.Size = new System.Drawing.Size(75, 23);
            this.AddLast.TabIndex = 2;
            this.AddLast.Text = "AddLast";
            this.AddLast.UseVisualStyleBackColor = true;
            this.AddLast.Click += new System.EventHandler(this.AddLast_Click);
            // 
            // Liczby
            // 
            this.Liczby.FormattingEnabled = true;
            this.Liczby.ItemHeight = 16;
            this.Liczby.Location = new System.Drawing.Point(599, 55);
            this.Liczby.Name = "Liczby";
            this.Liczby.Size = new System.Drawing.Size(120, 84);
            this.Liczby.TabIndex = 3;
            // 
            // WyswietlListe
            // 
            this.WyswietlListe.Location = new System.Drawing.Point(454, 116);
            this.WyswietlListe.Name = "WyswietlListe";
            this.WyswietlListe.Size = new System.Drawing.Size(100, 23);
            this.WyswietlListe.TabIndex = 4;
            this.WyswietlListe.Text = "WyswietlListe";
            this.WyswietlListe.UseVisualStyleBackColor = true;
            this.WyswietlListe.Click += new System.EventHandler(this.WyswietlListe_Click);
            // 
            // RemoveLast
            // 
            this.RemoveLast.Location = new System.Drawing.Point(621, 232);
            this.RemoveLast.Name = "RemoveLast";
            this.RemoveLast.Size = new System.Drawing.Size(98, 23);
            this.RemoveLast.TabIndex = 5;
            this.RemoveLast.Text = "RemoveLast";
            this.RemoveLast.UseVisualStyleBackColor = true;
            this.RemoveLast.Click += new System.EventHandler(this.RemoveLast_Click);
            // 
            // RemoveFirst
            // 
            this.RemoveFirst.Location = new System.Drawing.Point(454, 232);
            this.RemoveFirst.Name = "RemoveFirst";
            this.RemoveFirst.Size = new System.Drawing.Size(100, 23);
            this.RemoveFirst.TabIndex = 6;
            this.RemoveFirst.Text = "RemoveFirst";
            this.RemoveFirst.UseVisualStyleBackColor = true;
            this.RemoveFirst.Click += new System.EventHandler(this.RemoveFirst_Click);
            // 
            // InputTree
            // 
            this.InputTree.Location = new System.Drawing.Point(37, 116);
            this.InputTree.Name = "InputTree";
            this.InputTree.Size = new System.Drawing.Size(100, 22);
            this.InputTree.TabIndex = 7;
            // 
            // TreeItems
            // 
            this.TreeItems.FormattingEnabled = true;
            this.TreeItems.ItemHeight = 16;
            this.TreeItems.Location = new System.Drawing.Point(172, 116);
            this.TreeItems.Name = "TreeItems";
            this.TreeItems.Size = new System.Drawing.Size(120, 84);
            this.TreeItems.TabIndex = 8;
            // 
            // AddToTree
            // 
            this.AddToTree.Location = new System.Drawing.Point(37, 163);
            this.AddToTree.Name = "AddToTree";
            this.AddToTree.Size = new System.Drawing.Size(100, 23);
            this.AddToTree.TabIndex = 9;
            this.AddToTree.Text = "AddToTree";
            this.AddToTree.UseVisualStyleBackColor = true;
            this.AddToTree.Click += new System.EventHandler(this.AddToTree_Click);
            // 
            // WyswietlDrzewo
            // 
            this.WyswietlDrzewo.Location = new System.Drawing.Point(37, 232);
            this.WyswietlDrzewo.Name = "WyswietlDrzewo";
            this.WyswietlDrzewo.Size = new System.Drawing.Size(255, 23);
            this.WyswietlDrzewo.TabIndex = 10;
            this.WyswietlDrzewo.Text = "InOrder";
            this.WyswietlDrzewo.UseVisualStyleBackColor = true;
            this.WyswietlDrzewo.Click += new System.EventHandler(this.WyswietlDrzewo_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(37, 282);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "PreOrder";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(196, 282);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(96, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "PostOrder";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(408, 334);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 23);
            this.button3.TabIndex = 13;
            this.button3.Text = "StworzGraf";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // PrzejdzWszerz
            // 
            this.PrzejdzWszerz.Location = new System.Drawing.Point(408, 395);
            this.PrzejdzWszerz.Name = "PrzejdzWszerz";
            this.PrzejdzWszerz.Size = new System.Drawing.Size(111, 23);
            this.PrzejdzWszerz.TabIndex = 14;
            this.PrzejdzWszerz.Text = "PrzejdzWszerz";
            this.PrzejdzWszerz.UseVisualStyleBackColor = true;
            this.PrzejdzWszerz.Click += new System.EventHandler(this.PrzejdzWszerz_Click);
            // 
            // grafWynik
            // 
            this.grafWynik.FormattingEnabled = true;
            this.grafWynik.ItemHeight = 16;
            this.grafWynik.Location = new System.Drawing.Point(267, 334);
            this.grafWynik.Name = "grafWynik";
            this.grafWynik.Size = new System.Drawing.Size(120, 84);
            this.grafWynik.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grafWynik);
            this.Controls.Add(this.PrzejdzWszerz);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.WyswietlDrzewo);
            this.Controls.Add(this.AddToTree);
            this.Controls.Add(this.TreeItems);
            this.Controls.Add(this.InputTree);
            this.Controls.Add(this.RemoveFirst);
            this.Controls.Add(this.RemoveLast);
            this.Controls.Add(this.WyswietlListe);
            this.Controls.Add(this.Liczby);
            this.Controls.Add(this.AddLast);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.AddFirst);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AddFirst;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Button AddLast;
        private System.Windows.Forms.ListBox Liczby;
        private System.Windows.Forms.Button WyswietlListe;
        private System.Windows.Forms.Button RemoveLast;
        private System.Windows.Forms.Button RemoveFirst;
        private System.Windows.Forms.TextBox InputTree;
        private System.Windows.Forms.ListBox TreeItems;
        private System.Windows.Forms.Button AddToTree;
        private System.Windows.Forms.Button WyswietlDrzewo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button PrzejdzWszerz;
        private System.Windows.Forms.ListBox grafWynik;
    }
}

