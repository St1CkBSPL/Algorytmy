﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_dom
{
    internal class Graf
    {
        public List<Node> nodes = new List<Node>();

        public void DodajWierzcholek(Node node)
        {
            nodes.Add(node);
        }
        public void Polacz(Node node1, Node node2)
        {
            node1.sasiedzi.Add(node2);
            node2.sasiedzi.Add(node1);
        }
        public List<Node> Wszerz(Node start)
        {
            List<Node> odwiedzone = new List<Node>() { start };
            for (int i = 0; i < odwiedzone.Count; i++)
            {
                var tmp = odwiedzone[i];
                for (int j = 0; j < tmp.sasiedzi.Count; j++)
                {
                    if (!odwiedzone.Contains(tmp.sasiedzi[j]))
                    {
                        odwiedzone.Add(tmp.sasiedzi[j]);
                    }
                }
            }
            return odwiedzone;
        }
    }
}
